#!/usr/bin/env bash
# workload 테이블 초기화 + 스키마 하드게이트. 값·해시·시크릿은 출력하지 않는다.
set -euo pipefail

PSQL="sudo docker exec -i goexchange-db-postgres psql -U goexchange -d goexchange -v ON_ERROR_STOP=1"

echo "=== BEFORE: row counts ==="
$PSQL -c "SELECT 'orders' t, count(*) FROM orders UNION ALL SELECT 'trades', count(*) FROM trades UNION ALL SELECT 'ledger_entries', count(*) FROM ledger_entries UNION ALL SELECT 'wallets', count(*) FROM wallets UNION ALL SELECT 'users', count(*) FROM users UNION ALL SELECT 'cancel_commands', count(*) FROM cancel_commands UNION ALL SELECT 'order_idempotency_keys', count(*) FROM order_idempotency_keys UNION ALL SELECT 'trade_outbox_events', count(*) FROM trade_outbox_events UNION ALL SELECT 'failed_settlements', count(*) FROM failed_settlements UNION ALL SELECT 'failed_market_completions', count(*) FROM failed_market_completions UNION ALL SELECT 'failed_order_cancellations', count(*) FROM failed_order_cancellations UNION ALL SELECT 'reconciliation_violations', count(*) FROM reconciliation_violations;"

echo "=== TRUNCATE workload tables ==="
$PSQL -c "TRUNCATE TABLE order_idempotency_keys, cancel_commands, trade_outbox_events, failed_settlements, failed_market_completions, failed_order_cancellations, reconciliation_violations, ledger_entries, trades, orders, wallets, users RESTART IDENTITY CASCADE;"

echo "=== AFTER: row counts (all must be 0) ==="
$PSQL -c "SELECT 'orders' t, count(*) FROM orders UNION ALL SELECT 'trades', count(*) FROM trades UNION ALL SELECT 'ledger_entries', count(*) FROM ledger_entries UNION ALL SELECT 'wallets', count(*) FROM wallets UNION ALL SELECT 'users', count(*) FROM users UNION ALL SELECT 'cancel_commands', count(*) FROM cancel_commands UNION ALL SELECT 'order_idempotency_keys', count(*) FROM order_idempotency_keys UNION ALL SELECT 'trade_outbox_events', count(*) FROM trade_outbox_events UNION ALL SELECT 'failed_settlements', count(*) FROM failed_settlements UNION ALL SELECT 'failed_market_completions', count(*) FROM failed_market_completions UNION ALL SELECT 'failed_order_cancellations', count(*) FROM failed_order_cancellations UNION ALL SELECT 'reconciliation_violations', count(*) FROM reconciliation_violations;"

echo "=== GATE: goose version ==="
$PSQL -c "SELECT max(version_id) AS goose_version FROM goose_db_version;"

echo "=== GATE: order idempotency UNIQUE + partial index catalog definitions ==="
$PSQL -c "SELECT conname, pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid = 'order_idempotency_keys'::regclass ORDER BY conname;"
$PSQL -c "SELECT indexname, indexdef FROM pg_indexes WHERE tablename = 'order_idempotency_keys' ORDER BY indexname;"

echo "=== GATE: partial index catalog flags ==="
$PSQL -c "SELECT i.relname, x.indisvalid, x.indisready, x.indnkeyatts, x.indnatts, (x.indexprs IS NULL) AS no_exprs, pg_get_expr(x.indpred, x.indrelid) AS predicate FROM pg_class i JOIN pg_index x ON x.indexrelid = i.oid WHERE i.relname = 'order_idempotency_pending_updated_at';"

echo "=== index sizes BEFORE load ==="
$PSQL -c "SELECT pg_size_pretty(pg_relation_size('order_idempotency_keys')) AS table_size, pg_size_pretty(pg_relation_size('order_idempotency_keys_user_key_unique')) AS unique_index, pg_size_pretty(pg_relation_size('order_idempotency_pending_updated_at')) AS partial_index, pg_relation_size('order_idempotency_keys') AS table_bytes, pg_relation_size('order_idempotency_keys_user_key_unique') AS unique_bytes, pg_relation_size('order_idempotency_pending_updated_at') AS partial_bytes;"

echo "=== WAL LSN BEFORE ==="
$PSQL -c "SELECT pg_current_wal_lsn() AS wal_lsn_before;"
